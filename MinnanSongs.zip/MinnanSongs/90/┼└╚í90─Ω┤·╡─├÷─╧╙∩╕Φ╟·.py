#引入库
import requests
import re

#请求的url设置
url_list=["https://wwwapi.kugou.com/yy/index.php?r=play/getdata&dataType=json&hash=93A52C0F081E1DB69623150895E4D2DD&album_id=936890&dfid=3MWBln20TbPD0A0Fh32yHzlt&mid=0108f9926054deda4703841006b397da&platid=4&_=1562577672480",
          "https://wwwapi.kugou.com/yy/index.php?r=play/getdata&dataType=json&hash=3797F90B55F04FE6032D32DF5A14B85A&album_id=625801&dfid=3MWBln20TbPD0A0Fh32yHzlt&mid=0108f9926054deda4703841006b397da&platid=4&_=1562575351090",
          "https://wwwapi.kugou.com/yy/index.php?r=play/getdata&dataType=json&hash=48B3974D9CEADAFF228109BBE90282B5&album_id=625810&dfid=3MWBln20TbPD0A0Fh32yHzlt&mid=0108f9926054deda4703841006b397da&platid=4&_=1562575449167",
          "https://wwwapi.kugou.com/yy/index.php?r=play/getdata&dataType=json&hash=D00ABFBCDE590F858786E25C6D145500&album_id=&dfid=3MWBln20TbPD0A0Fh32yHzlt&mid=0108f9926054deda4703841006b397da&platid=4&_=1562575517667",
          "https://wwwapi.kugou.com/yy/index.php?r=play/getdata&dataType=json&hash=3E5459BD2645E1C24350074E457BEDB0&album_id=11883807&dfid=3MWBln20TbPD0A0Fh32yHzlt&mid=0108f9926054deda4703841006b397da&platid=4&_=1562575630861",
          "https://wwwapi.kugou.com/yy/index.php?r=play/getdata&dataType=json&hash=7EAF52988670D39FC4293CEEEE980D14&album_id=625801&dfid=3MWBln20TbPD0A0Fh32yHzlt&mid=0108f9926054deda4703841006b397da&platid=4&_=1562576369286",
          "https://wwwapi.kugou.com/yy/index.php?r=play/getdata&dataType=json&hash=D978359CC33B0CE20DE6C677641E2E8B&album_id=625811&dfid=3MWBln20TbPD0A0Fh32yHzlt&mid=0108f9926054deda4703841006b397da&platid=4&_=1562576459064",
          "https://wwwapi.kugou.com/yy/index.php?r=play/getdata&dataType=json&hash=8A3816605BE97AB13C31C66427D54EB7&album_id=&dfid=3MWBln20TbPD0A0Fh32yHzlt&mid=0108f9926054deda4703841006b397da&platid=4&_=1562576547602",
          "https://wwwapi.kugou.com/yy/index.php?r=play/getdata&dataType=json&hash=A752B88437550A7A44F1C8A575B0585A&album_id=8575009&dfid=3MWBln20TbPD0A0Fh32yHzlt&mid=0108f9926054deda4703841006b397da&platid=4&_=1562576648550",
          "https://wwwapi.kugou.com/yy/index.php?r=play/getdata&dataType=json&hash=9B712FA1AE2ECC3AB51DA54CFD71537E&album_id=&dfid=3MWBln20TbPD0A0Fh32yHzlt&mid=0108f9926054deda4703841006b397da&platid=4&_=1562576787689",
          "https://wwwapi.kugou.com/yy/index.php?r=play/getdata&dataType=json&hash=47123FB99CF3E8219F266E0C2C752A9B&album_id=625809&dfid=3MWBln20TbPD0A0Fh32yHzlt&mid=0108f9926054deda4703841006b397da&platid=4&_=1562576864399",
          "https://wwwapi.kugou.com/yy/index.php?r=play/getdata&dataType=json&hash=3779FF76F77CD11117095D322673BB14&album_id=19349112&dfid=3MWBln20TbPD0A0Fh32yHzlt&mid=0108f9926054deda4703841006b397da&platid=4&_=1562576906507",
          "https://wwwapi.kugou.com/yy/index.php?r=play/getdata&dataType=json&hash=C0D9B8F2F9809EAF912A46302945D442&album_id=19349112&dfid=3MWBln20TbPD0A0Fh32yHzlt&mid=0108f9926054deda4703841006b397da&platid=4&_=1562576950971",
          "https://wwwapi.kugou.com/yy/index.php?r=play/getdata&dataType=json&hash=945E9BDA154539026DECAF55008889FC&album_id=4098294&dfid=3MWBln20TbPD0A0Fh32yHzlt&mid=0108f9926054deda4703841006b397da&platid=4&_=1562576991518",
          "https://wwwapi.kugou.com/yy/index.php?r=play/getdata&dataType=json&hash=3E36B054C67236416FC3B455584C8046&album_id=625808&dfid=3MWBln20TbPD0A0Fh32yHzlt&mid=0108f9926054deda4703841006b397da&platid=4&_=1562577080424",
          "https://wwwapi.kugou.com/yy/index.php?r=play/getdata&dataType=json&hash=913050338B64CC519842B5B575D9403C&album_id=11883807&dfid=3MWBln20TbPD0A0Fh32yHzlt&mid=0108f9926054deda4703841006b397da&platid=4&_=1562577132793",
          "https://wwwapi.kugou.com/yy/index.php?r=play/getdata&dataType=json&hash=9B688AEAFE3AA4EEF87C9589615954A5&album_id=580883&dfid=3MWBln20TbPD0A0Fh32yHzlt&mid=0108f9926054deda4703841006b397da&platid=4&_=1562577194411",
          "https://wwwapi.kugou.com/yy/index.php?r=play/getdata&dataType=json&hash=171BA921C4EA51D05A4F3EF6CBE28583&album_id=625807&dfid=3MWBln20TbPD0A0Fh32yHzlt&mid=0108f9926054deda4703841006b397da&platid=4&_=1562577245554",
          "https://wwwapi.kugou.com/yy/index.php?r=play/getdata&dataType=json&hash=A01AD3BE38F6BBD0CAE093A14E2259F4&album_id=625809&dfid=3MWBln20TbPD0A0Fh32yHzlt&mid=0108f9926054deda4703841006b397da&platid=4&_=1562577301421",
          "https://wwwapi.kugou.com/yy/index.php?r=play/getdata&dataType=json&hash=DF9F53B97E8BDFBACE925ED56E1CB199&album_id=936890&dfid=3MWBln20TbPD0A0Fh32yHzlt&mid=0108f9926054deda4703841006b397da&platid=4&_=1562577360904",
          "https://wwwapi.kugou.com/yy/index.php?r=play/getdata&dataType=json&hash=3B85AC984F8DF3CF56A8697D76E37F6D&album_id=625800&dfid=3MWBln20TbPD0A0Fh32yHzlt&mid=0108f9926054deda4703841006b397da&platid=4&_=1562577399092",
          "https://wwwapi.kugou.com/yy/index.php?r=play/getdata&dataType=json&hash=EA844462C9A72032C409522B14982DAC&album_id=19349112&dfid=3MWBln20TbPD0A0Fh32yHzlt&mid=0108f9926054deda4703841006b397da&platid=4&_=1562577443951",
          "https://wwwapi.kugou.com/yy/index.php?r=play/getdata&dataType=json&hash=A131432AD83D7D72F95EFF6323FC6BE2&album_id=936890&dfid=3MWBln20TbPD0A0Fh32yHzlt&mid=0108f9926054deda4703841006b397da&platid=4&_=1562577486467",
          "https://wwwapi.kugou.com/yy/index.php?r=play/getdata&dataType=json&hash=BE64BD456D759AB088CD376DBDE3BE32&album_id=625801&dfid=3MWBln20TbPD0A0Fh32yHzlt&mid=0108f9926054deda4703841006b397da&platid=4&_=1562577524446",
          "https://wwwapi.kugou.com/yy/index.php?r=play/getdata&dataType=json&hash=AD7851673A2558CA9FD345C077C66875&album_id=625801&dfid=3MWBln20TbPD0A0Fh32yHzlt&mid=0108f9926054deda4703841006b397da&platid=4&_=1562577603017",
          "https://wwwapi.kugou.com/yy/index.php?r=play/getdata&dataType=json&hash=3ADCFA0DB2830148C478F425B097A7CC&album_id=1531483&dfid=3MWBln20TbPD0A0Fh32yHzlt&mid=0108f9926054deda4703841006b397da&platid=4&_=1562577640919",
          "https://wwwapi.kugou.com/yy/index.php?r=play/getdata&dataType=json&hash=93A52C0F081E1DB69623150895E4D2DD&album_id=936890&dfid=3MWBln20TbPD0A0Fh32yHzlt&mid=0108f9926054deda4703841006b397da&platid=4&_=1562577672479"

]
#伪装真正的服务器
headers={
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.100 Safari/537.36'
}

#遍历列表依次获取数据
for i in url_list:
    res=requests.get(i,headers=headers)

    js=res.json()
    song_name=js['data']['audio_name']
    song_lyrics=js['data']['lyrics']
    lyrics_=re.sub('[00:00.32]','',song_lyrics)

    re_lyrics=re.sub('\d','',lyrics_)                                    

    end_lyrics=re_lyrics.translate(str.maketrans('','','[]'))

    f=open('C://Users//misswang//Desktop//test//爬取90年代闽南歌//'+song_name+'.txt','a')
    f.write(end_lyrics)
    f.close()
